package com.example.livesmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LivesMod implements ModInitializer, ClientModInitializer {

    public static final String MOD_ID = "livesmod";
    public static final int MAX_LIVES = 5;

    public record SyncLivesPayload(int lives) implements CustomPayload {
        public static final CustomPayload.Id<SyncLivesPayload> ID = 
                new CustomPayload.Id<>(Identifier.of(MOD_ID, "sync_lives"));

        public static final PacketCodec<RegistryByteBuf, SyncLivesPayload> CODEC = 
                PacketCodec.tuple(
                        PacketCodecs.INTEGER, SyncLivesPayload::lives,
                        SyncLivesPayload::new
                );

        @Override
        public CustomPayload.Id<? extends CustomPayload> getId() {
            return ID;
        }
    }

    public static class LivesState extends PersistentState {
        private final Map<UUID, Integer> livesMap = new HashMap<>();

        public int getLives(UUID uuid) {
            return livesMap.getOrDefault(uuid, MAX_LIVES);
        }

        public void setLives(UUID uuid, int lives) {
            livesMap.put(uuid, lives);
            this.markDirty();
        }

        @Override
        public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
            NbtCompound livesNbt = new NbtCompound();
            livesMap.forEach((uuid, lives) -> livesNbt.putInt(uuid.toString(), lives));
            nbt.put("PlayerLives", livesNbt);
            return nbt;
        }

        public static LivesState createFromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
            LivesState state = new LivesState();
            NbtCompound livesNbt = nbt.getCompound("PlayerLives");
            for (String key : livesNbt.getKeys()) {
                try {
                    UUID uuid = UUID.fromString(key);
                    int lives = livesNbt.getInt(key);
                    state.livesMap.put(uuid, lives);
                } catch (IllegalArgumentException ignored) {}
            }
            return state;
        }

        public static LivesState getServerState(ServerWorld world) {
            return world.getServer().getOverworld().getPersistentStateManager().getOrCreate(
                    new PersistentState.Type<>(
                            LivesState::new,
                            LivesState::createFromNbt,
                            null
                    ),
                    MOD_ID + "_lives"
            );
        }
    }

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(SyncLivesPayload.ID, SyncLivesPayload.CODEC);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            LivesState state = LivesState.getServerState(player.getServerWorld());
            int currentLives = state.getLives(player.getUuid());
            ServerPlayNetworking.send(player, new SyncLivesPayload(currentLives));
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof ServerPlayerEntity player) {
                ServerWorld world = player.getServerWorld();
                LivesState state = LivesState.getServerState(world);
                UUID uuid = player.getUuid();

                int currentLives = state.getLives(uuid) - 1;

                if (currentLives <= 0) {
                    state.setLives(uuid, MAX_LIVES);
                    ServerPlayNetworking.send(player, new SyncLivesPayload(MAX_LIVES));
                    player.networkHandler.disconnect(Text.literal("§cYou ran out of lives! §eKicked for 1 second."));
                } else {
                    state.setLives(uuid, currentLives);
                    ServerPlayNetworking.send(player, new SyncLivesPayload(currentLives));
                    player.sendMessage(Text.literal("§cYou lost a life! Lives remaining: " + currentLives), false);
                }
            }
        });
    }

    @Environment(EnvType.CLIENT)
    private static int clientLivesCount = MAX_LIVES;

    @Override
    @Environment(EnvType.CLIENT)
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SyncLivesPayload.ID, (payload, context) -> {
            clientLivesCount = payload.lives();
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden || client.player.isCreative() || client.player.isSpectator()) {
                return;
            }

            Identifier FULL_LIFE = Identifier.of(MOD_ID, "textures/gui/life_full.png");
            Identifier EMPTY_LIFE = Identifier.of(MOD_ID, "textures/gui/life_empty.png");

            int width = client.getWindow().getScaledWidth();
            int height = client.getWindow().getScaledHeight();

            int startX = width / 2 - 91;
            int startY = height - 49;

            for (int i = 0; i < MAX_LIVES; i++) {
                Identifier texture = (i < clientLivesCount) ? FULL_LIFE : EMPTY_LIFE;
                drawContext.drawTexture(
                        RenderLayer::getGuiTextured,
                        texture,
                        startX + (i * 10),
                        startY,
                        0.0f, 0.0f,
                        9, 9,
                        9, 9
                );
            }
        });
    }
}